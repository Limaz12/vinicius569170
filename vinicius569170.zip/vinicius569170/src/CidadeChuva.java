import java.util.Random;
import java.util.Scanner;

// GS Cidade em Dia de Chuva
// Integrantes: Vinicius Shuo Yan Hung - RM 569170 - Pietro Suchenski - RM 573102 - Felipe Lima Huerta - RM 568933

public class CidadeChuva {

    // Metodo principal que roda o fluxo inteiro: le os RMs, monta o bairro, simula a chuva e mostra o relatorio
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);

        System.out.println("Simulador de Escoamento e Alagamentos - CitizenTech");
        System.out.println("Informe quantos integrantes tem na equipe (1 a 3):");
        int numMembros = leitor.nextInt();

        int[] rms = new int[numMembros];
        for (int pos = 0; pos < rms.length; pos++) {
            System.out.println("Digite o RM do integrante " + (pos + 1) + ":");
            rms[pos] = leitor.nextInt();
        }

        // Calcula o RM unico do grupo e puxa as configuracoes do bairro
        int rmTotal = calcularRmEquipe(rms);
        System.out.println("RM total da equipe: " + rmTotal);

        int[] config = calcularParametros(rmTotal);
        int totalLinhas = config[0];
        int totalColunas = config[1];
        int qtdPassos = config[2];
        int limiteAlagamento = config[3];
        int sentidoVizinhos = config[4];

        String textoOrdem = "1 (Oeste, Sul, Leste, Norte)";
        if (sentidoVizinhos == 0) {
            textoOrdem = "0 (Norte, Leste, Sul, Oeste)";
        }

        System.out.println("Configuracao do bairro -> Grade: " + totalLinhas + "x" + totalColunas
                + " | Passos: " + qtdPassos + " | Limiar de alerta: " + limiteAlagamento
                + " cm | Ordem de vizinhos: " + textoOrdem);

        // Gera o relevo e a chuva inicial usando o RM como semente para ficar igual ao gabarito
        Random sorteio = new Random(rmTotal);
        int[][] relevo = gerarAltitude(sorteio, totalLinhas, totalColunas);
        int[][] aguaAtual = gerarMatriz(sorteio, totalLinhas, totalColunas, 0, 10);

        // Guarda uma copia da chuva do comeco pra conferir se a agua total nao sumiu e rodar o modo ingenuo depois
        int[][] aguaComeco = copiar(aguaAtual);

        imprimir(relevo, "Altitude do terreno (cm):");
        imprimir(aguaComeco, "Lamina de agua inicial (cm):");

        int[] passoLinha = criarDeslocamentoLinha(sentidoVizinhos);
        int[] passoColuna = criarDeslocamentoColuna(sentidoVizinhos);

        // Roda a simulacao ciclo por ciclo (Parte B)
        int[][] estadoPasso3 = null;

        for (int ciclo = 1; ciclo <= qtdPassos; ciclo++) {
            int[][] fotoCiclo = copiar(aguaAtual);
            int volumeAntes = somar(fotoCiclo);

            aguaAtual = simularPasso(relevo, aguaAtual, passoLinha, passoColuna);

            int volumeDepois = somar(aguaAtual);

            System.out.println("Ciclo " + ciclo + " concluido");
            System.out.println("Total de agua antes do ciclo: " + volumeAntes + " cm");
            System.out.println("Total de agua depois do ciclo: " + volumeDepois + " cm");

            mostrarAlertasDoCiclo(fotoCiclo, aguaAtual, limiteAlagamento, ciclo);

            if (ciclo == 1) {
                imprimir(aguaAtual, "Lamina de agua apos o 1o ciclo (cm):");
            }

            if (ciclo == 3) {
                estadoPasso3 = copiar(aguaAtual);
            }
        }

        imprimir(aguaAtual, "Lamina de agua final apos " + qtdPassos + " ciclos (cm):");
        System.out.println("Conferencia geral -> Agua no inicio: " + somar(aguaComeco)
                + " cm | Agua no fim: " + somar(aguaAtual) + " cm");

        boolean[][] mapaRisco = marcarAlerta(aguaAtual, limiteAlagamento);
        int totalPontosRisco = contarAlerta(mapaRisco);
        System.out.println("Total de trechos em alerta de alagamento: " + totalPontosRisco);

        // Monta o relatorio da Defesa Civil (Parte C)
        imprimirMapaAlerta(mapaRisco);

        int[] somaPorFaixa = calcularAguaPorLinha(aguaAtual);
        System.out.println("Volume de agua acumulado por linha (cm):");
        for (int lin = 0; lin < somaPorFaixa.length; lin++) {
            System.out.println("Linha " + lin + ": " + somaPorFaixa[lin]);
        }

        int faixaMaisCritica = encontrarLinhaCritica(somaPorFaixa);
        System.out.println("Linha mais critica: " + faixaMaisCritica + " (" + somaPorFaixa[faixaMaisCritica] + " cm)");

        int[] resumoManchas = contarManchasAlagadas(mapaRisco, passoLinha, passoColuna);
        System.out.println("Quantidade de regioes alagadas: " + resumoManchas[0]);
        System.out.println("Tamanho da maior regiao alagada: " + resumoManchas[1]);

        // Faz o rastreamento da celula (a, b) no 3o passo para responder a Parte D
        int posA = rmTotal % totalLinhas;
        int posB = (rmTotal / 7) % totalColunas;
        int valorCorreto = estadoPasso3[posA][posB];

        int[][] aguaSemFoto = copiar(aguaComeco);
        for (int ciclo = 1; ciclo <= 3; ciclo++) {
            aguaSemFoto = simularPassoIngenuo(relevo, aguaSemFoto, passoLinha, passoColuna);
        }
        int valorIngenuo = aguaSemFoto[posA][posB];

        // Bloco final obrigatorio no formato exato pedido para correcao automatica
        System.out.println("RESUMO RM=" + rmTotal);
        System.out.println("ALERTA=" + totalPontosRisco);
        System.out.println("CRITICA=" + faixaMaisCritica + " AGUA=" + somaPorFaixa[faixaMaisCritica]);
        System.out.println("D1=" + valorCorreto + " D2=" + valorIngenuo);

        leitor.close();
    }

    // Soma os RMs digitados no vetor para obter o numero base que personaliza toda a prova
    public static int calcularRmEquipe(int[] rms) {
        int somaRms = 0;
        for (int idx = 0; idx < rms.length; idx++) {
            somaRms += rms[idx];
        }
        return somaRms;
    }

    // Define o tamanho da grade, quantos passos vao rodar, o limite de alagamento e a ordem dos vizinhos usando o RM
    public static int[] calcularParametros(int rm) {
        int linhas = 8 + rm % 3;
        int colunas = 10 + (rm / 10) % 3;
        int passos = 4 + (rm / 100) % 3;
        int limiar = 10 + 2 * (rm % 4);
        int regraOrdem = rm % 2;

        int[] vetorConfig = new int[5];
        vetorConfig[0] = linhas;
        vetorConfig[1] = colunas;
        vetorConfig[2] = passos;
        vetorConfig[3] = limiar;
        vetorConfig[4] = regraOrdem;
        return vetorConfig;
    }

    // Monta o relevo do bairro deixando a linha do meio (N/2) mais baixa para formar um vale onde a chuva escorre
    public static int[][] gerarAltitude(Random gerador, int n, int m) {
        int[][] terreno = new int[n][m];
        for (int lin = 0; lin < n; lin++) {
            for (int col = 0; col < m; col++) {
                terreno[lin][col] = 3 * Math.abs(lin - n / 2) + gerador.nextInt(5);
            }
        }
        return terreno;
    }

    // Sorteia valores inteiros entre minimo e maximo para preencher a quantidade inicial de chuva em cada celula
    public static int[][] gerarMatriz(Random gerador, int n, int m, int minimo, int maximo) {
        int[][] tabela = new int[n][m];
        for (int lin = 0; lin < n; lin++) {
            for (int col = 0; col < m; col++) {
                tabela[lin][col] = minimo + gerador.nextInt(maximo - minimo + 1);
            }
        }
        return tabela;
    }

    // Devolve quanto somar na linha para achar os 4 vizinhos na ordem certa da equipe (horario ou anti-horario)
    public static int[] criarDeslocamentoLinha(int ordem) {
        if (ordem == 0) {
            return new int[] { -1, 0, 1, 0 };
        }
        return new int[] { 0, 1, 0, -1 };
    }

    // Devolve quanto somar na coluna para achar os 4 vizinhos na ordem certa e resolver empates de nivel
    public static int[] criarDeslocamentoColuna(int ordem) {
        if (ordem == 0) {
            return new int[] { 0, 1, 0, -1 };
        }
        return new int[] { -1, 0, 1, 0 };
    }

    // Confere se uma coordenada (i, j) esta dentro dos limites da matriz para nao estourar indice nas bordas
    public static boolean dentro(int i, int j, int n, int m) {
        return i >= 0 && i < n && j >= 0 && j < m;
    }

    // Cria uma matriz nova e copia numero por numero para evitar que mudar uma matriz estrague a original
    public static int[][] copiar(int[][] matriz) {
        int qtdLinhas = matriz.length;
        int qtdColunas = matriz[0].length;
        int[][] duplicada = new int[qtdLinhas][qtdColunas];

        for (int lin = 0; lin < qtdLinhas; lin++) {
            for (int col = 0; col < qtdColunas; col++) {
                duplicada[lin][col] = matriz[lin][col];
            }
        }
        return duplicada;
    }

    // Mostra um titulo e imprime a matriz em formato de tabela separada por tabulacao usando apenas println
    public static void imprimir(int[][] matriz, String titulo) {
        System.out.println(titulo);
        for (int lin = 0; lin < matriz.length; lin++) {
            String textoLinha = "";
            for (int col = 0; col < matriz[0].length; col++) {
                if (col > 0) {
                    textoLinha += "\t";
                }
                textoLinha += matriz[lin][col];
            }
            System.out.println(textoLinha);
        }
    }

    // Soma todos os valores da matriz para provar que a quantidade total de agua continua a mesma apos escoar
    public static int somar(int[][] matriz) {
        int acumulado = 0;
        for (int lin = 0; lin < matriz.length; lin++) {
            for (int col = 0; col < matriz[0].length; col++) {
                acumulado += matriz[lin][col];
            }
        }
        return acumulado;
    }

    // Roda um ciclo de escoamento olhando a foto do inicio do passo e salvando as mudancas numa matriz nova
    public static int[][] simularPasso(int[][] altitude, int[][] lamina, int[] deslocamentoLinha, int[] deslocamentoColuna) {
        int qtdLinhas = altitude.length;
        int qtdColunas = altitude[0].length;
        int[][] proximoEstado = copiar(lamina);

        for (int lin = 0; lin < qtdLinhas; lin++) {
            for (int col = 0; col < qtdColunas; col++) {
                int qtdEscoar = lamina[lin][col] / 2;

                if (qtdEscoar > 0) {
                    int menorAlturaAgua = altitude[lin][col] + lamina[lin][col];
                    int vizinhoEscolhido = -1;

                    for (int dir = 0; dir < 4; dir++) {
                        int vizLin = lin + deslocamentoLinha[dir];
                        int vizCol = col + deslocamentoColuna[dir];

                        if (dentro(vizLin, vizCol, qtdLinhas, qtdColunas)) {
                            int alturaAguaVizinho = altitude[vizLin][vizCol] + lamina[vizLin][vizCol];
                            if (alturaAguaVizinho < menorAlturaAgua) {
                                menorAlturaAgua = alturaAguaVizinho;
                                vizinhoEscolhido = dir;
                            }
                        }
                    }

                    if (vizinhoEscolhido != -1) {
                        int alvoLin = lin + deslocamentoLinha[vizinhoEscolhido];
                        int alvoCol = col + deslocamentoColuna[vizinhoEscolhido];
                        proximoEstado[lin][col] -= qtdEscoar;
                        proximoEstado[alvoLin][alvoCol] += qtdEscoar;
                    }
                }
            }
        }

        return proximoEstado;
    }

    // Faz o passo alterando a propria matriz na hora sem tirar foto antes para mostrar o erro na questao D2
    public static int[][] simularPassoIngenuo(int[][] altitude, int[][] lamina, int[] deslocamentoLinha, int[] deslocamentoColuna) {
        int qtdLinhas = altitude.length;
        int qtdColunas = altitude[0].length;

        for (int lin = 0; lin < qtdLinhas; lin++) {
            for (int col = 0; col < qtdColunas; col++) {
                int qtdEscoar = lamina[lin][col] / 2;

                if (qtdEscoar > 0) {
                    int menorAlturaAgua = altitude[lin][col] + lamina[lin][col];
                    int vizinhoEscolhido = -1;

                    for (int dir = 0; dir < 4; dir++) {
                        int vizLin = lin + deslocamentoLinha[dir];
                        int vizCol = col + deslocamentoColuna[dir];

                        if (dentro(vizLin, vizCol, qtdLinhas, qtdColunas)) {
                            int alturaAguaVizinho = altitude[vizLin][vizCol] + lamina[vizLin][vizCol];
                            if (alturaAguaVizinho < menorAlturaAgua) {
                                menorAlturaAgua = alturaAguaVizinho;
                                vizinhoEscolhido = dir;
                            }
                        }
                    }

                    if (vizinhoEscolhido != -1) {
                        int alvoLin = lin + deslocamentoLinha[vizinhoEscolhido];
                        int alvoCol = col + deslocamentoColuna[vizinhoEscolhido];
                        lamina[lin][col] -= qtdEscoar;
                        lamina[alvoLin][alvoCol] += qtdEscoar;
                    }
                }
            }
        }

        return lamina;
    }

    // Cria uma matriz booleana marcando como true toda celula onde a agua chegou ou passou do limiar de alerta
    public static boolean[][] marcarAlerta(int[][] lamina, int limiarAlerta) {
        int qtdLinhas = lamina.length;
        int qtdColunas = lamina[0].length;
        boolean[][] gradeAlerta = new boolean[qtdLinhas][qtdColunas];

        for (int lin = 0; lin < qtdLinhas; lin++) {
            for (int col = 0; col < qtdColunas; col++) {
                gradeAlerta[lin][col] = lamina[lin][col] >= limiarAlerta;
            }
        }
        return gradeAlerta;
    }

    // Conta quantas celulas ficaram marcadas como alagadas na matriz booleana para resumir o impacto da chuva
    public static int contarAlerta(boolean[][] alerta) {
        int contador = 0;
        for (int lin = 0; lin < alerta.length; lin++) {
            for (int col = 0; col < alerta[0].length; col++) {
                if (alerta[lin][col]) {
                    contador++;
                }
            }
        }
        return contador;
    }

    // Desenha o mapa do bairro usando # para pontos alagados e ponto (.) para pontos normais
    public static void imprimirMapaAlerta(boolean[][] alerta) {
        System.out.println("Mapa de alerta (# = alagado, . = normal):");
        for (int lin = 0; lin < alerta.length; lin++) {
            String linhaTexto = "";
            for (int col = 0; col < alerta[0].length; col++) {
                if (col > 0) {
                    linhaTexto += "\t";
                }
                if (alerta[lin][col]) {
                    linhaTexto += "#";
                } else {
                    linhaTexto += ".";
                }
            }
            System.out.println(linhaTexto);
        }
    }

    // Calcula quanta agua ficou acumulada em cada linha do mapa para saber qual faixa sofreu mais
    public static int[] calcularAguaPorLinha(int[][] lamina) {
        int qtdLinhas = lamina.length;
        int qtdColunas = lamina[0].length;
        int[] totais = new int[qtdLinhas];

        for (int lin = 0; lin < qtdLinhas; lin++) {
            int somaLinha = 0;
            for (int col = 0; col < qtdColunas; col++) {
                somaLinha += lamina[lin][col];
            }
            totais[lin] = somaLinha;
        }
        return totais;
    }

    // Acha o indice da linha com mais agua acumulada, mantendo a primeira que aparecer se der empate
    public static int encontrarLinhaCritica(int[] aguaPorLinha) {
        int indiceMaior = 0;
        for (int lin = 1; lin < aguaPorLinha.length; lin++) {
            if (aguaPorLinha[lin] > aguaPorLinha[indiceMaior]) {
                indiceMaior = lin;
            }
        }
        return indiceMaior;
    }

    // Avisa no console sempre que uma celula ultrapassa o limite de alagamento durante o ciclo atual
    public static void mostrarAlertasDoCiclo(int[][] antes, int[][] depois, int limite, int numeroCiclo) {
        for (int lin = 0; lin < depois.length; lin++) {
            for (int col = 0; col < depois[0].length; col++) {
                if (antes[lin][col] < limite && depois[lin][col] >= limite) {
                    System.out.println("Alerta no ciclo " + numeroCiclo + ": a celula (" + lin + ", " + col
                            + ") chegou a " + depois[lin][col] + " cm de agua.");
                }
            }
        }
    }

    // Percorre as celulas alagadas vizinhas usando vetores simples para contar quantas manchas existem e o tamanho da maior
    public static int[] contarManchasAlagadas(boolean[][] alerta, int[] deslocamentoLinha, int[] deslocamentoColuna) {
        int qtdLinhas = alerta.length;
        int qtdColunas = alerta[0].length;
        boolean[][] jaPassou = new boolean[qtdLinhas][qtdColunas];
        int[] buscaLin = new int[qtdLinhas * qtdColunas];
        int[] buscaCol = new int[qtdLinhas * qtdColunas];

        int totalManchas = 0;
        int maiorTamanho = 0;

        for (int lin = 0; lin < qtdLinhas; lin++) {
            for (int col = 0; col < qtdColunas; col++) {
                if (alerta[lin][col] && !jaPassou[lin][col]) {
                    totalManchas++;
                    int ponteiroLeitura = 0;
                    int ponteiroEscrita = 0;

                    buscaLin[ponteiroEscrita] = lin;
                    buscaCol[ponteiroEscrita] = col;
                    ponteiroEscrita++;
                    jaPassou[lin][col] = true;

                    while (ponteiroLeitura < ponteiroEscrita) {
                        int atualLin = buscaLin[ponteiroLeitura];
                        int atualCol = buscaCol[ponteiroLeitura];
                        ponteiroLeitura++;

                        for (int dir = 0; dir < 4; dir++) {
                            int vizLin = atualLin + deslocamentoLinha[dir];
                            int vizCol = atualCol + deslocamentoColuna[dir];

                            if (dentro(vizLin, vizCol, qtdLinhas, qtdColunas)
                                    && alerta[vizLin][vizCol] && !jaPassou[vizLin][vizCol]) {
                                jaPassou[vizLin][vizCol] = true;
                                buscaLin[ponteiroEscrita] = vizLin;
                                buscaCol[ponteiroEscrita] = vizCol;
                                ponteiroEscrita++;
                            }
                        }
                    }

                    if (ponteiroEscrita > maiorTamanho) {
                        maiorTamanho = ponteiroEscrita;
                    }
                }
            }
        }

        int[] resultado = new int[2];
        resultado[0] = totalManchas;
        resultado[1] = maiorTamanho;
        return resultado;
    }
}
